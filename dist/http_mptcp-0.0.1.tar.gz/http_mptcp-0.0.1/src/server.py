from http.server import *
import socket
from socketserver import BaseServer

class HTTPServer(http.server.HTTPServer):
    def __init__(self, server_address, RequestHandlerClass, bind_and_activate=True):
        """Constructor.  May be extended, do not override."""
        print("bob")
        BaseServer.__init__(self, server_address, RequestHandlerClass)
        self.socket = socket.socket(family=self.address_family,
                                    type=self.socket_type,
                                    proto=socket.IPPROTO_MPTCP)
        if bind_and_activate:
            try:
                self.server_bind()
                self.server_activate()
            except:
                self.server_close()
                raise